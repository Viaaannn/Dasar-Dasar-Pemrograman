from django.shortcuts import render

def home(request):
    context = {
        'nama': 'Eka Nurviantoro',
        'profesi': 'Mahasiswa',
        'deskripsi': 'Saya adalah seorang Mahasiswa prodi Teknik Informatika.',
        'email': 'eka.nrva22@gmail.com',
        'telp': '+62 857-7476-8907',
        'lokasi': 'Depok, Indonesia'
    }
    return render(request, 'home.html', context)

def about(request):
    context = {
        'pendidikan': [
            {'tahun': '2020-2023', 'Madrasah Aliyah': 'Al-Ittihad', 'jurusan': 'IPS', 'status': 'Lulus'},
            {'tahun': '2025-Sampai Sekarang', 'instansi': 'STT Nurul Fikri', 'prodi': 'Teknik Informatika', 'status': 'Lulus'},
        ],
        'organisasi': [
            {'tahun': '2020-2023', 'nama': 'ISDA (Ikatan Santri Darul Akhyar)', 'posisi': 'Ketua'},
        ]
    }
    return render(request, 'about.html', context)

def gallery(request):
    context = {
        'images': [
            {'src': 'images/Mengajar.jpeg', 'alt': 'Kegiatan Mengajar', 'caption': 'Kegiatan Mengajar'},
            {'src': 'images/Seminar.jpeg', 'alt': 'Kegiatan Seminar Teknologi', 'caption': 'Seminar AI & Machine Learning'},
            {'src': 'images/Work.jpeg', 'alt': 'Kegiatan Team Building', 'caption': 'Team Building Event'},
        ]
    }
    return render(request, 'gallery.html', context)