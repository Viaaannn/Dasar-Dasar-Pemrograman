# Folder Images

Letakkan gambar Anda di sini dengan nama:
- kegiatan1.jpg
- kegiatan2.jpg
- kegiatan3.jpg

Format yang didukung: JPG, JPEG, PNG

Rekomendasi ukuran: 800x600px atau rasio 4:3
