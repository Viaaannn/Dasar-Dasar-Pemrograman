# Django Profile Website

Website profile pribadi sederhana menggunakan Django Framework dan Bootstrap.

## Struktur Project
- my_profile_project/ - Folder utama project
- profile_app/ - Django app untuk profile
- templates/ - Template HTML
- static/ - File CSS dan images

## Cara Menjalankan

1. Install Django:
```bash
pip install django
```

2. Jalankan migrasi:
```bash
python manage.py migrate
```

3. Jalankan server:
```bash
python manage.py runserver
```

4. Buka browser dan akses: http://127.0.0.1:8000/

## Customisasi

### Mengganti Data Profile
Edit file `profile_app/views.py` untuk mengganti:
- Nama, profesi, deskripsi (fungsi home)
- Riwayat pendidikan (fungsi about)
- Riwayat organisasi (fungsi about)

### Menambah Gambar Gallery
1. Simpan gambar di folder `profile_app/static/images/`
2. Beri nama: kegiatan1.jpg, kegiatan2.jpg, kegiatan3.jpg
3. Gambar akan otomatis tampil di halaman gallery

### Mengubah Style
Edit file `profile_app/static/css/style.css`

## Fitur
- Responsive design dengan Bootstrap 5
- Navigasi menu yang smooth
- Design minimalis dan clean
- Mudah dikustomisasi

## Menu
- Home: Profile diri
- About Me: Riwayat pendidikan dan organisasi
- Gallery: Foto kegiatan
